package com.example.calculator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import java.math.BigDecimal
import java.math.MathContext

enum class Op(val symbol: String) { ADD("+"), SUBTRACT("−"), MULTIPLY("×"), DIVIDE("÷") }

class CalculatorViewModel : ViewModel() {
    var display by mutableStateOf("0")
        private set
    var expression by mutableStateOf("")
        private set

    private var accumulator: BigDecimal? = null
    private var pendingOp: Op? = null
    private var startNewNumber = true
    private var error = false

    fun onDigit(d: Char) {
        if (error) onClear()
        if (startNewNumber) {
            display = if (d == '.') "0." else d.toString()
            startNewNumber = false
            return
        }
        if (d == '.' && display.contains('.')) return
        if (display.length >= 16) return
        display = if (display == "0" && d != '.') d.toString() else display + d
    }

    fun onOperator(op: Op) {
        if (error) return
        val current = BigDecimal(display)
        val acc = accumulator
        val pending = pendingOp
        val newAcc = when {
            acc != null && pending != null && !startNewNumber ->
                apply(acc, current, pending) ?: return showError()
            acc != null && pending != null -> acc   // just switching operator
            else -> current
        }
        accumulator = newAcc
        pendingOp = op
        display = format(newAcc)
        expression = "${format(newAcc)} ${op.symbol}"
        startNewNumber = true
    }

    fun onEquals() {
        if (error) return
        val acc = accumulator ?: return
        val op = pendingOp ?: return
        val current = BigDecimal(display)
        val result = apply(acc, current, op) ?: return showError()
        expression = "${format(acc)} ${op.symbol} ${format(current)} ="
        display = format(result)
        accumulator = null
        pendingOp = null
        startNewNumber = true
    }

    fun onClear() {
        display = "0"
        expression = ""
        accumulator = null
        pendingOp = null
        startNewNumber = true
        error = false
    }

    fun onBackspace() {
        if (error || startNewNumber) return
        display = display.dropLast(1)
        if (display.isEmpty() || display == "-") {
            display = "0"
            startNewNumber = true
        }
    }

    fun onToggleSign() {
        if (error || display == "0") return
        display = if (display.startsWith("-")) display.drop(1) else "-$display"
    }

    fun onPercent() {
        if (error) return
        display = format(BigDecimal(display).divide(BigDecimal(100)))
        startNewNumber = true
    }

    private fun apply(a: BigDecimal, b: BigDecimal, op: Op): BigDecimal? = when (op) {
        Op.ADD -> a.add(b)
        Op.SUBTRACT -> a.subtract(b)
        Op.MULTIPLY -> a.multiply(b)
        Op.DIVIDE -> if (b.signum() == 0) null else a.divide(b, MathContext.DECIMAL64)
    }

    private fun showError() {
        display = "Can't divide by 0"
        expression = ""
        accumulator = null
        pendingOp = null
        startNewNumber = true
        error = true
    }

    private fun format(n: BigDecimal): String {
        val s = n.round(MathContext(12)).stripTrailingZeros()
        return if (s.abs() < BigDecimal("1e12")) s.toPlainString() else s.toString()
    }
}
