package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    CalculatorScreen()
                }
            }
        }
    }
}

private enum class Kind { DIGIT, OPERATOR, FUNCTION }

private data class Key(val label: String, val kind: Kind, val action: (CalculatorViewModel) -> Unit)

private fun digit(c: Char) = Key(c.toString(), Kind.DIGIT) { it.onDigit(c) }
private fun op(o: Op) = Key(o.symbol, Kind.OPERATOR) { it.onOperator(o) }

private val keys = listOf(
    listOf(
        Key("AC", Kind.FUNCTION) { it.onClear() },
        Key("⌫", Kind.FUNCTION) { it.onBackspace() },
        Key("%", Kind.FUNCTION) { it.onPercent() },
        op(Op.DIVIDE)
    ),
    listOf(digit('7'), digit('8'), digit('9'), op(Op.MULTIPLY)),
    listOf(digit('4'), digit('5'), digit('6'), op(Op.SUBTRACT)),
    listOf(digit('1'), digit('2'), digit('3'), op(Op.ADD)),
    listOf(
        Key("±", Kind.FUNCTION) { it.onToggleSign() },
        digit('0'),
        digit('.'),
        Key("=", Kind.OPERATOR) { it.onEquals() }
    )
)

@Composable
fun CalculatorScreen(vm: CalculatorViewModel = viewModel()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.Bottom
    ) {
        Text(
            text = vm.expression,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.End,
            fontSize = 24.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
        val size = when {
            vm.display.length <= 8 -> 64.sp
            vm.display.length <= 12 -> 48.sp
            else -> 34.sp
        }
        Text(
            text = vm.display,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            textAlign = TextAlign.End,
            fontSize = size,
            fontWeight = FontWeight.Light,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1
        )
        keys.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                row.forEach { key ->
                    CalcButton(key, Modifier.weight(1f)) { key.action(vm) }
                }
            }
        }
    }
}

@Composable
private fun CalcButton(key: Key, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (key.kind) {
        Kind.DIGIT -> cs.surfaceVariant to cs.onSurfaceVariant
        Kind.OPERATOR -> cs.primary to cs.onPrimary
        Kind.FUNCTION -> cs.secondaryContainer to cs.onSecondaryContainer
    }
    Surface(
        onClick = onClick,
        modifier = modifier.aspectRatio(1f),
        shape = CircleShape,
        color = bg,
        contentColor = fg
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(key.label, fontSize = 28.sp, color = fg)
        }
    }
}
